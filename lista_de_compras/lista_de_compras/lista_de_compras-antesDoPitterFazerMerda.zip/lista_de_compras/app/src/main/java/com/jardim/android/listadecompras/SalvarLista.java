package com.jardim.android.listadecompras; // trocar a package quando for pro projeto final

import android.content.Context;

import java.io.FileOutputStream;
import java.util.ArrayList;

import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;



public class SalvarLista {
    //private static String SALVO_COM_SUCESSO = "A lista foi salva com sucesso";
    private static String QUEBRA_DE_LINHA = "\n";
    private  static  String TAG = "SalvaLista";

    public boolean verificaSeAListaExiste(String pNomeDoArquivo){
            File fTestarSeExiste = new File(pNomeDoArquivo);

            return fTestarSeExiste.exists() && !fTestarSeExiste.isDirectory();

        }
    public boolean salvarLista(ArrayList<String> pStringsASalvar, String pNomeDoArquivo , Context pContext){ // Não se esqueça de utilizar verificaSeAListaExiste na activiy

        FileOutputStream outputStream; // Objeto usado para salvar os dados no arquivo
        String strAListaInteira = ""; // String onde o ArrayList será formatado para ser salvo;
            for (int i = 0; i < pStringsASalvar.size(); i++) {
                strAListaInteira = strAListaInteira + pStringsASalvar.get(i) + "\n";
            }
            try {
                outputStream = pContext.openFileOutput(pNomeDoArquivo, pContext.MODE_PRIVATE); // Abre o arquivo a ser escrito, de moto privado para que apenas esta aplicação tenha acess
                outputStream.write(strAListaInteira.getBytes());
                outputStream.close();
                return true;

            } catch (Exception e) {
                e.printStackTrace();
                return false;

            }

    }

    public ArrayList<String> resgatarLista(String pNomeDoArquivo, Context pContext){
        ArrayList<String> alreturn = new ArrayList<>();

        try {
            FileInputStream fin = pContext.openFileInput(pNomeDoArquivo);
            int iTamanhoDoArquivo;
            String strNovoItem = null;
            String strAuxiliar;

            // Lê dentro do arquivo até ele chegar ao fim (-1)
            while ((iTamanhoDoArquivo = fin.read()) != -1) {
                strNovoItem = null;
              strAuxiliar =  Character.toString((char) iTamanhoDoArquivo);
              if(!strAuxiliar.equals(QUEBRA_DE_LINHA)){ // verifica se é uma quebra de linha, que signica uma nova palavra;
                    // add & append content
                    strNovoItem += Character.toString((char) iTamanhoDoArquivo);
              }else{
                  alreturn.add(strNovoItem);
              }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return alreturn;
    }

    public ArrayList<String> verListas(Context pContext){
        File verArquivos = pContext.getFilesDir(); // /Cria uma variável para manipular o diretório
        ArrayList<String> arListas = new ArrayList<>();
        String[] strListaArquivos = verArquivos.list();
        if(strListaArquivos == null){
            Log.e(TAG, "Diretório não encontrado");
        }else if(strListaArquivos.length != 0){
            for(String str : strListaArquivos){
                arListas.add(str);

            }
            return arListas; // caso exista pelo menos um arquivo, retorna todos os arquivos
        }//for
        return  arListas; // Case seja null ( diretório inexistente)
    }//verListas
}//SalvarLista



