package com.jardim.android.listadecompras;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Comprando extends AppCompatActivity {


    //Handler para ListView
    ListView.OnItemLongClickListener mHandlerClickListenerColor = new ListView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            view.setSelected(true);
            view.setBackgroundColor(0x0000FF00);
            return true;
        }//onItemLongClick
    };//mHandlerClickListener

    //declarando SalvarLista
    SalvarLista salvarLista = new SalvarLista();
    //Declarando contexto
    Context mContext;
    //Declarando membros de dados
    TextView mTvQuantidadeDeItens;
    TextView mTvQuantidadeDeItensSelecionados;

    Button mBtnFecharCompra;

    ArrayList<String> mListaProdutos;
    ListView mLvComprando;
    ArrayAdapter<String> mAdLvComprando;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comprando);

        init();
    }//onCreate

    void iniciandoListView(){
        mLvComprando = findViewById(R.id.idLvComprando);
        mListaProdutos = new ArrayList<>();
        mAdLvComprando = new ArrayAdapter<>(mContext, android.R.layout.simple_list_item_1, mListaProdutos);
        mLvComprando.setAdapter(mAdLvComprando);
    }//iniciandoListView
    void init(){
        mContext = this;
        mTvQuantidadeDeItens = findViewById(R.id.idTvQuantidadeDeItens);
        mTvQuantidadeDeItensSelecionados = findViewById(R.id.idTvQuantidadeDeItensSelecionados);
        mBtnFecharCompra = findViewById(R.id.idBtnFecharCompra);
        //iniciando listView
        this.iniciandoListView();

        this.receberIntentVerListas();
    }//init

    void receberIntentVerListas(){
       Intent intent = getIntent();
       String nomeLista = intent.getStringExtra(VerListas.CHAVE_VER_LISTAS);
       ArrayList<String> pLista = salvarLista.resgatarLista(nomeLista, mContext);

       ClasseAuxiliar.mostrarMensagem(mContext, pLista.toString());
    }//

}//fim da classe
